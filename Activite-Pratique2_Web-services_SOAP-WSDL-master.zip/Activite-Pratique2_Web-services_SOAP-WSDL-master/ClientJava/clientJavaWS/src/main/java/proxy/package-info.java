@jakarta.xml.bind.annotation.XmlSchema(namespace = "http://ws.miaad.org/")
package proxy;
